import { useState } from "react";

export default function CharacterCreator() {
  const [character, setCharacter] = useState({
    name: "",
    age: "",
    role: "",
    traits: "",
    backstory: ""
  });

  const [savedCharacters, setSavedCharacters] = useState([]);

  const handleChange = (e) => {
    setCharacter({ ...character, [e.target.name]: e.target.value });
  };

  const handleSave = () => {
    setSavedCharacters([...savedCharacters, character]);
    setCharacter({ name: "", age: "", role: "", traits: "", backstory: "" });
  };

  return (
    <div style={{ padding: 20, maxWidth: 600, margin: "0 auto" }}>
      <h1>Create a Character</h1>
      <div>
        <input placeholder="Name" name="name" value={character.name} onChange={handleChange} />
        <input placeholder="Age" name="age" value={character.age} onChange={handleChange} />
        <input placeholder="Role" name="role" value={character.role} onChange={handleChange} />
        <textarea placeholder="Traits" name="traits" value={character.traits} onChange={handleChange} />
        <textarea placeholder="Backstory" name="backstory" value={character.backstory} onChange={handleChange} />
        <button onClick={handleSave}>Save Character</button>
      </div>

      <div style={{ marginTop: 40 }}>
        <h2>Saved Characters</h2>
        {savedCharacters.map((char, idx) => (
          <div key={idx} style={{ border: "1px solid #ccc", padding: 10, marginBottom: 10 }}>
            <strong>{char.name}</strong> ({char.age}) - {char.role}
            <p><strong>Traits:</strong> {char.traits}</p>
            <p><strong>Backstory:</strong> {char.backstory}</p>
          </div>
        ))}
      </div>
    </div>
  );
}