import React from "react";
import ReactDOM from "react-dom/client";
import CharacterCreator from "./CharacterCreator";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <CharacterCreator />
  </React.StrictMode>
);